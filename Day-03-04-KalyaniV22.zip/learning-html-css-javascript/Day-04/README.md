# Day 04 — CSS Mini Project: Flexbox Pricing Cards

**Program:** AD TECH MERN Foundation Learning Program (Task-02)
**Built with:** HTML + CSS only (no JavaScript)

## About this project
A responsive pricing page with 3 plan cards (Basic, Pro, Enterprise), built to
apply everything practiced on Day 03 (Flexbox) plus additional CSS concepts
from the assignment's practice list: layouts, positioning, animations, and
media queries.

## CSS concepts demonstrated
- **Flexbox** — `.cards-container` uses `display: flex` with `flex-wrap` and
  `gap` to lay out the cards; each `.card` is itself a flex column so the
  button always sits at the bottom regardless of feature-list length.
- **Positioning** — the "Most Popular" badge uses `position: absolute`
  relative to its parent card (`position: relative`).
- **Animations/Transitions** — cards lift up smoothly on hover using
  `transition` and `transform`.
- **Responsive Design / Media Queries** — the layout adapts at `900px` and
  `600px` breakpoints, eventually stacking cards in a single column on
  mobile screens.
- **Layouts** — a full-page vertical flex layout (header → cards → footer)
  keeps the footer at the bottom even on short pages.

## Files
- `index.html` — page markup (3 pricing cards)
- `style.css` — all styling, layout, animations, and media queries

## How to view
Open `index.html` in any browser. Resize the window to see the responsive
behavior, and hover over a card to see the lift animation.
